import streamlit as st
import numpy as np
import datetime
import pandas as pd
import mysql.connector
from mysql.connector import Error
from helper import add_logo
import plotly.express as px

st.set_page_config(page_title="Sentiment Overview", 
                   page_icon="📈",
                   layout="wide")

st.markdown("# Sentiment Overview")
"Bootcamp Influencer 2024 PT. Benih Citra Asia"

def connect_to_db():
    try:
        connection = mysql.connector.connect(
            host='10.240.20.20',
            database='bootcamp',
            user='root',
            password='ZNqOhS/VS/Pd8w',
            port='8906'
        )
        if connection.is_connected():
            return connection
    except Error as e:
        st.error("Tidak dapat terhubung ke database, periksa koneksi database terlebih dahulu.")
        return None

db_connection = connect_to_db()

if db_connection is not None:
    query_users = """
        SELECT * FROM bootcamp_users
    """
    users_data = pd.read_sql(query_users, con=db_connection)

    query_sentiment_collection = """
        SELECT * FROM bootcamp_sentiment_collection
    """
    sentiment_data = pd.read_sql(query_sentiment_collection, con=db_connection)

    sentiment_data['like'] = sentiment_data['like'].replace({'undefined': 0}).astype(int)
    sentiment_data['time'] = sentiment_data['time'].apply(lambda x: str(x)[:10])
    sentiment_data['interaction'] = sentiment_data['like'] + sentiment_data['reply'] + sentiment_data['retweet']

    users_data['combined'] = users_data['kode_users'] + " - " + users_data['fullname']

    username_list = users_data['combined'].tolist()
    selected_users = st.multiselect("Pilih Kandidat", username_list)

    if selected_users:
        selected_codes = [user.split(" - ")[0] for user in selected_users]

        filtered_sentiment_data = sentiment_data[sentiment_data['username'].isin(selected_codes)]
        
        st.markdown("### Daftar Kandidat :")
        for i, user in enumerate(selected_users):
            st.write(f"{i+1}. **{user}**")
    else:
        filtered_sentiment_data = sentiment_data.copy()

    df_sentiment = filtered_sentiment_data['prediction'].value_counts().reset_index()
    df_sentiment.columns = ['prediction', 'total']
    df_sentiment['prediction'] = df_sentiment['prediction'].replace({0: 'Negatif', 1: 'Positif', 2: 'Netral'})

    df_tweet = filtered_sentiment_data.groupby(["time", "prediction"]).agg({
                            'like': ['count', 'sum'],
                            'reply': ['sum'],
                            'retweet': ['sum']
                            }).reset_index()
    df_tweet.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in df_tweet.columns]

    plotly_colors = ['red', '#636EFA']

    add_logo("https://upload.wikimedia.org/wikipedia/commons/archive/c/ce/20210909091155%21Twitter_Logo.png", 150)

    today = datetime.datetime.now()
    past_3m = datetime.date(today.year, today.month - 3, 1)

    date = st.sidebar.date_input(
        "Masukkan rentang waktu",
        (past_3m, today),
        datetime.date(today.year - 10, 1, 1),
        datetime.date(today.year + 10, 12, 31),
    )

    a11, a12 = st.columns(2)

    with a11:
        st.markdown("### Distribusi Sentimen")
        fig = px.pie(df_sentiment, 
                     names='prediction',
                     values='total',  
                     hole=.3,
                     height=300,
                     color_discrete_sequence=plotly_colors[::-1]) 
        fig.update_traces(textposition='inside', textinfo='percent+label', textfont_size=18)
        fig.update_layout(showlegend=False, margin=dict(l=20, r=20, t=20, b=20))
        fig.update_yaxes(visible=False, fixedrange=True)
        st.plotly_chart(fig, use_container_width=True)

    with a12:
        st.markdown("### Interaksi Sentimen dari Waktu ke Waktu")
        fig = px.line(df_tweet, x='time', y='like_sum', color='prediction',
                      hover_data=['like_sum', 'reply_sum', 'retweet_sum'], 
                      labels={'like_sum': 'like',
                              'reply_sum': 'reply',
                              'retweet_sum': 'retweet',
                              'prediction': 'sentiment'},
                      height=400,
                      color_discrete_sequence=plotly_colors)
        fig.update_yaxes(visible=False, fixedrange=True)
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("## Sampel Tweet")
    st.dataframe(filtered_sentiment_data[['like', 'reply', 'retweet', 'time', 'username', 'clean', 'prediction']].sort_values(['like'], ascending=False),
                 use_container_width=True,
                 hide_index=True)
