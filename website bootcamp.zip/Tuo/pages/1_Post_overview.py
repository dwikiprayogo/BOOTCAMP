import streamlit as st
import pandas as pd
import numpy as np
import datetime
import mysql.connector
from mysql.connector import Error
import plotly.express as px
from helper import add_logo

st.set_page_config(page_title="Post Overview", 
                   page_icon="📈",
                   layout="wide")

st.markdown("# Post Overview")
"Bootcamp Influencer 2024 PT. Benih Citra Asia"

try:
    db_connection = mysql.connector.connect(
        host='10.240.20.20',
        database='bootcamp',
        user='root',
        password='ZNqOhS/VS/Pd8w',
        port='8906'
    )

    query_post = "SELECT * FROM bootcamp_post_collection"
    query_users = "SELECT * FROM bootcamp_users"
    
    data = pd.read_sql(query_post, db_connection)
    users = pd.read_sql(query_users, db_connection)

    data['like'] = data['like'].replace({'undefined': 0}).astype(int)
    data['time'] = pd.to_datetime(data['time']).dt.strftime('%Y-%m-%d')
    data['interaction'] = data['like'] + data['reply'] + data['retweet']
    data['hashtag'] = data['hashtag'].apply(lambda x: x.lower().strip().replace("ᅠᅠ", "").replace("ᅠ", ""))

    users['user_display'] = users['kode_users'] + ' - ' + users['fullname']
    
    selected_users_display = st.multiselect("Pilih Kandidat", users['user_display'].tolist())

    if selected_users_display:
        st.markdown("### Daftar Kandidat :")
        for i, user_display in enumerate(selected_users_display, start=1):
            st.write(f"{i}. **{user_display}**")

        selected_users = users[users['user_display'].isin(selected_users_display)]
        selected_usernames = selected_users['kode_users'].tolist()

        data = data[data['username'].isin(selected_usernames)]

    df_tweet = data.groupby(["hashtag"]).agg({
                            'like':['count','sum'],
                            'reply' : ['sum'],
                            'retweet' : ['sum'],
                            'interaction' : ['sum'],
                            'username':['nunique']
                            }).reset_index()
    df_tweet.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in df_tweet.columns]
    df_tweet.sort_values(by=['interaction_sum'], ascending=False, inplace=True)

    add_logo("https://upload.wikimedia.org/wikipedia/commons/archive/c/ce/20210909091155%21Twitter_Logo.png", 150)

    today = datetime.datetime.now()
    past_3m = today - datetime.timedelta(days=90)

    date = st.sidebar.date_input(
        "Masukkan rentang waktu",
        (past_3m, today),
        datetime.date(today.year-10, 1, 1),
        datetime.date(today.year+10, 12, 31)
    )

    date = list(date)

    if not date or len(date) == 0:
        st.markdown("""
            <div style='background-color: white; padding: 10px;'>
                <p style='color: red; font-size: 18px;'>Silahkan pilih rentang waktu terlebih dahulu.</p>
            </div>
        """, unsafe_allow_html=True)
    else:
        if len(date) == 1:
            date.append(date[0] + datetime.timedelta(days=1))

        date[1] = date[1] + datetime.timedelta(days=1)

        filtered_data = data[(data['time'] >= str(date[0])) & (data['time'] <= str(date[1]))]

        data2 = filtered_data.groupby(["time"]).agg({
                                    'hashtag':['nunique','unique'],
                                    'like':['sum'],
                                    'reply' : ['sum'],
                                    'retweet' : ['sum'],
                                    'interaction' : ['sum'],
                                    }).reset_index()
        data2.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in data2.columns]

        a11, a12 = st.columns(2)

        with a11:  
            a111, a112 = st.columns(2)
            with a111:
                st.metric(label="Jumlah Post",
                          value=f"{(df_tweet.shape[0])}")
                st.metric(label="Jumlah Komentar",
                          value=f"{(df_tweet['like_count'].sum())}")

            with a112:
                st.metric(label="Jumlah User",
                          value=f"{(df_tweet['username_nunique'].sum())}")
                st.metric(label="Total Engagement",
                          value=f"{(df_tweet['interaction_sum'].sum())}")

        st.markdown("## Total Hashtag")

        data2_overall = data.groupby(["time"]).agg({
                                    'hashtag':['nunique','unique'],
                                    'like':['sum'],
                                    'reply' : ['sum'],
                                    'retweet' : ['sum'],
                                    'interaction' : ['sum'],
                                    }).reset_index()
        data2_overall.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in data2_overall.columns]

        if not data2_overall.empty:
            st.dataframe(data2_overall,
                         hide_index=True,
                         column_config={
                            'time': 'Date',
                            'hashtag_nunique': 'Total Hashtag',
                            'like_sum': 'Likes',
                            'reply_sum': 'Replies',
                            'retweet_sum': 'Retweets',
                            'interaction_sum': 'Engagement',
                         },
                         use_container_width=True)

        st.markdown("## Hashtag Details")

        st.dataframe(df_tweet[['hashtag', 'like_count', 'username_nunique', 'retweet_sum', 'like_sum', 'reply_sum', 'interaction_sum']],
                         use_container_width=True,
                         hide_index=True,
                         column_config={
                            'hashtag':'Hashtag',
                            'like_count':"Tweets",
                            'like_sum':'Likes',
                            'reply_sum':'Replies',
                            'retweet_sum':'Retweets',
                            'interaction_sum':'Engagement',
                            'username_nunique':'User'
                         })

except Error as e:
    st.error("Tidak dapat terhubung ke database, Periksa koneksi database terlebih dahulu.")
