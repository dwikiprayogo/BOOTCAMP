import streamlit as st
import numpy as np
import datetime
import pandas as pd
import mysql.connector
from mysql.connector import Error
from helper import add_logo
import plotly.express as px
from numerize import numerize

st.set_page_config(page_title="Keyword Overview", 
                   page_icon="📈",
                   layout="wide")

st.markdown("# Keyword Overview")
"Bootcamp Influencer 2024 PT. Benih Citra Asia"

try:
    db_connection = mysql.connector.connect(
        host='10.240.20.20',
        database='bootcamp',
        user='root',
        password='ZNqOhS/VS/Pd8w',
        port='8906'
    )

    query_keyword = "SELECT * FROM bootcamp_keyword_collection"
    data = pd.read_sql(query_keyword, con=db_connection)

    query_users = "SELECT * FROM bootcamp_users"
    users = pd.read_sql(query_users, con=db_connection)

    data['like'] = data['like'].replace({'undefined': 0}).astype(int)
    data['time'] = data['time'].apply(lambda x: x[:10])
    data['interaction'] = data.apply(lambda x: x['like'] + x['reply'] + x['retweet'], axis=1)
    data.dropna(subset=['clean'], axis=0, inplace=True)
    data['clean'] = data['clean'].apply(lambda x: x.lower().strip().replace("ᅠᅠ", "").replace("ᅠ", ""))

    users['user_display'] = users['kode_users'] + ' - ' + users['fullname']

    selected_users_display = st.multiselect("Pilih Kandidat", users['user_display'].tolist())

    if selected_users_display:
        st.markdown("### Daftar Kandidat yang Dipilih:")
        for i, user_display in enumerate(selected_users_display, start=1):
            st.write(f"{i}. **{user_display}**")

        selected_users = users[users['user_display'].isin(selected_users_display)]
        selected_usernames = selected_users['kode_users'].tolist()

        filtered_data = data[data['username'].isin(selected_usernames)]
    else:
        filtered_data = data.copy()

    df_tweet = filtered_data.groupby(["clean"]).agg({
                                    'like': ['count', 'sum'],
                                    'reply': ['sum'],
                                    'retweet': ['sum'],
                                    'interaction': ['sum'],
                                    'username': ['nunique']
                                    }).reset_index()
    df_tweet.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in df_tweet.columns]
    df_tweet.sort_values(by=['interaction_sum'], ascending=False, inplace=True)

    data2 = filtered_data.groupby(["time"]).agg({
                                'clean': ['nunique', 'unique'],
                                'like': ['sum'],
                                'reply': ['sum'],
                                'retweet': ['sum'],
                                'interaction': ['sum'],
                                }).reset_index()
    data2.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in data2.columns]

    a11, a12 = st.columns(2)

    with a11:  
            st.markdown("### Total Keyword")
            a111, a112 = st.columns(2)
            with a111:
                st.metric(label="Jumlah Keyword", value=f"{numerize.numerize(df_tweet.shape[0])}")
                st.metric(label="Jumlah Komentar", value=f"{numerize.numerize(df_tweet['like_count'].sum().item())}")

            with a112:
                st.metric(label="Jumlah User", value=f"{numerize.numerize(df_tweet['username_nunique'].sum().item())}")
                st.metric(label="Total Engagement", value=f"{numerize.numerize(df_tweet['interaction_sum'].sum().item())}")

    with a12:
            fig = px.line(data2, x='time', y='clean_nunique', 
                          hover_data=['like_sum', 'reply_sum', 'retweet_sum'],
                          labels={'like_sum': 'like', 'reply_sum': 'reply', 'retweet_sum': 'retweet', 'clean_nunique': 'unique keyword'},
                          height=400)
            fig.update_yaxes(visible=False, fixedrange=True)
            fig.update_layout(showlegend=False)

            st.plotly_chart(fig, use_container_width=True)

    st.dataframe(data2,
                     hide_index=True,
                     column_config={
                        'clean': 'Keyword',
                        'like_count': "Tweets",
                        'like_sum': 'Likes',
                        'reply_sum': 'Replies',
                        'retweet_sum': 'Retweets',
                        'interaction_sum': 'Engagement',
                        'username_nunique': 'User',
                        'clean_nunique': 'Total Keyword',
                        'clean_unique': 'Unique Keyword'
                    },
                    use_container_width=True)

    st.markdown("## Keyword Details")
    st.dataframe(df_tweet[['clean', 'like_count', 'username_nunique', 'retweet_sum', 'like_sum', 'reply_sum', 'interaction_sum']],
                     use_container_width=True,
                     hide_index=True,
                     column_config={
                        'clean': 'Keyword',
                        'like_count': "Tweets",
                        'like_sum': 'Likes',
                        'reply_sum': 'Replies',
                        'retweet_sum': 'Retweets',
                        'interaction_sum': 'Engagement',
                        'username_nunique': 'User',
                    })

except Error as e:
    st.error("Tidak dapat terhubung ke database, periksa koneksi database terlebih dahulu.")
