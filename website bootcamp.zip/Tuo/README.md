# sentimen-prj
Analisis Sentimen pengguna sosial media Twitter terkait topik PRJ (Pekan Raya Jakarta)

## Anggota Tim
Anggota tim Project Internship UMN CONSULTING Grup 2
| No | Nama                |
|----|---------------------|
| 1  | Try Yuliandre Pajar |
| 2  | Tuti Amalia         |
| 3  | Wahyu Dwi Prasetio  |