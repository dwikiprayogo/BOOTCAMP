import streamlit as st
import numpy as np
import datetime
import pandas as pd
import mysql.connector
from mysql.connector import Error
from helper import add_logo
import plotly.express as px

st.set_page_config(page_title="Sentiment Overview", 
                   page_icon="📈",
                   layout="wide")

st.markdown("# Sentiment Overview")

def connect_to_db():
    try:
        connection = mysql.connector.connect(
            host='10.240.20.20',
            database='bootcamp',
            user='root',
            password='ZNqOhS/VS/Pd8w',
            port='8906'
        )
        if connection.is_connected():
            return connection
    except Error as e:
        st.error("Tidak dapat terhubung ke database, Periksa koneksi database terlebih dahulu.")
        return None

db_connection = connect_to_db()

if db_connection is not None:
    query_sentiment_collection = """
        SELECT `like`, reply, retweet, time, username, clean, prediction 
        FROM bootcamp_sentiment_collection
    """

    data = pd.read_sql(query_sentiment_collection, con=db_connection)

    data['like'] = data['like'].replace({'undefined': 0}).astype(int)
    data['time'] = data['time'].apply(lambda x: str(x)[:10])
    data['interaction'] = data['like'] + data['reply'] + data['retweet']

    df_sentiment = data['prediction'].value_counts().reset_index()
    df_sentiment.columns = ['prediction', 'total']
    df_sentiment['prediction'] = df_sentiment['prediction'].replace({0: 'Negatif', 1: 'Positif', 2: 'Netral'})

    df_tweet = data.groupby(["time", "prediction"]).agg({
                            'like': ['count', 'sum'],
                            'reply': ['sum'],
                            'retweet': ['sum']
                            }).reset_index()
    df_tweet.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in df_tweet.columns]

    plotly_colors = ['red', '#636EFA']

    add_logo("https://upload.wikimedia.org/wikipedia/commons/archive/c/ce/20210909091155%21Twitter_Logo.png", 150)

    today = datetime.datetime.now()
    past_3m = datetime.date(today.year, today.month-3, 1)

    date = st.sidebar.date_input(
        "Masukkan rentang waktu",
        (past_3m, today),
        datetime.date(today.year-10, 1, 1),
        datetime.date(today.year+10, 12, 31),
    )

    date = list(date)

    if len(date) == 0:
        st.markdown("<p style='color: red; font-size: 18px;'>Silahkan pilih rentang waktu terlebih dahulu.</p>", unsafe_allow_html=True)
    else:
        if len(date) == 1:
            date.append(date[0] + datetime.timedelta(days=1))

        date_start, date_end = date[0], date[1]
        date_end += datetime.timedelta(days=1)

        filtered_data = data[(data['time'] >= str(date_start)) & (data['time'] <= str(date_end))]

        if filtered_data.empty:
            st.write("Tidak ada data yang tersedia untuk rentang tanggal yang dipilih.")
        else:
            a11, a12 = st.columns(2)

            with a11:
                st.markdown("### Distribusi Sentimen")
                fig = px.pie(df_sentiment, 
                             names='prediction',
                             values='total',  
                             hole=.3,
                             height=300,
                             color_discrete_sequence=plotly_colors[::-1]) 
                fig.update_traces(textposition='inside', textinfo='percent+label', textfont_size=18)
                fig.update_layout(showlegend=False, margin=dict(l=20, r=20, t=20, b=20))
                fig.update_yaxes(visible=False, fixedrange=True)
                st.plotly_chart(fig, use_container_width=True)

            with a12:
                st.markdown("### Interaksi Sentimen dari Waktu ke Waktu")
                fig = px.line(df_tweet, x='time', y='like_sum', color='prediction',
                              hover_data=['like_sum', 'reply_sum', 'retweet_sum'], 
                              labels={'like_sum': 'like',
                                      'reply_sum': 'reply',
                                      'retweet_sum': 'retweet',
                                      'prediction': 'sentiment'},
                              height=400,
                              color_discrete_sequence=plotly_colors)
                fig.update_yaxes(visible=False, fixedrange=True)
                fig.update_layout(showlegend=False)
                st.plotly_chart(fig, use_container_width=True)

            st.markdown("## Sampel Tweet")
            st.dataframe(filtered_data[['like', 'reply', 'retweet', 'time', 'username', 'clean', 'prediction']].sort_values(['like'], ascending=False),
                         use_container_width=True,
                         hide_index=True)
