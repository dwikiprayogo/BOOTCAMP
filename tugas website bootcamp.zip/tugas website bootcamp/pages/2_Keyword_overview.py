import streamlit as st
import numpy as np
import datetime
import pandas as pd
import mysql.connector
from mysql.connector import Error
from helper import add_logo
import plotly.express as px
from numerize import numerize

st.set_page_config(page_title="Keyword Overview", 
                   page_icon="📈",
                   layout="wide")

st.markdown("# Keyword Overview")

try:
    db_connection = mysql.connector.connect(
        host='10.240.20.20',
        database='bootcamp',
        user='root',
        password='ZNqOhS/VS/Pd8w',
        port='8906'
    )

    query = """
        SELECT `like`, reply, retweet, time, username, clean, prediction 
        FROM bootcamp_keyword_collection
    """
    data = pd.read_sql(query, con=db_connection)

    data['like'] = data['like'].replace({'undefined': 0}).astype(int)
    data['time'] = data['time'].apply(lambda x: x[:10])
    data['interaction'] = data.apply(lambda x: x['like'] + x['reply'] + x['retweet'], axis=1)
    data.dropna(subset=['clean'], axis=0, inplace=True)
    data['clean'] = data['clean'].apply(lambda x: x.lower().strip().replace("ᅠᅠ", "").replace("ᅠ", ""))

    add_logo("https://upload.wikimedia.org/wikipedia/commons/archive/c/ce/20210909091155%21Twitter_Logo.png", 150)

    today = datetime.datetime.now()
    past_3m = datetime.date(today.year, today.month - 3, 1)

    date = list(st.sidebar.date_input(
        "Masukkan rentang waktu",
        (past_3m, today),
        datetime.date(today.year - 10, 1, 1),
        datetime.date(today.year + 10, 12, 31),
    ))

    if len(date) == 0:
        st.markdown("""
            <div style='background-color: white; padding: 10px;'>
                <p style='color: red; font-size: 18px;'>Silahkan pilih rentang waktu terlebih dahulu.</p>
            </div>
        """, unsafe_allow_html=True)
    else:
        if len(date) == 1:
            date.append(date[0] + datetime.timedelta(days=1))

        date[1] = date[1] + datetime.timedelta(days=1)

        filtered_data = data[(data['time'] >= str(date[0])) & (data['time'] <= str(date[1]))]

        if filtered_data.empty:
            st.write("Tidak ada data yang tersedia untuk rentang tanggal yang dipilih.")
        else:
            df_tweet = filtered_data.groupby(["clean"]).agg({
                                    'like': ['count', 'sum'],
                                    'reply': ['sum'],
                                    'retweet': ['sum'],
                                    'interaction': ['sum'],
                                    'username': ['nunique']
                                    }).reset_index()
            df_tweet.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in df_tweet.columns]
            df_tweet.sort_values(by=['interaction_sum'], ascending=False, inplace=True)

            data2 = filtered_data.groupby(["time"]).agg({
                                    'clean': ['nunique', 'unique'],
                                    'like': ['sum'],
                                    'reply': ['sum'],
                                    'retweet': ['sum'],
                                    'interaction': ['sum'],
                                    }).reset_index()
            data2.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in data2.columns]

            a11, a12 = st.columns(2)

            with a11:  
                st.markdown("### Total Keyword")
                a111, a112 = st.columns(2)
                with a111:
                    st.metric(label="Jumlah Keyword", value=f"{numerize.numerize(df_tweet.shape[0])}")
                    st.metric(label="Jumlah Komentar", value=f"{numerize.numerize(df_tweet['like_count'].sum().item())}")

                with a112:
                    st.metric(label="Jumlah User", value=f"{numerize.numerize(df_tweet['username_nunique'].sum().item())}")
                    st.metric(label="Total Engagement", value=f"{numerize.numerize(df_tweet['interaction_sum'].sum().item())}")

            with a12:
                fig = px.line(data2, x='time', y='clean_nunique', 
                              hover_data=['like_sum', 'reply_sum', 'retweet_sum'],
                              labels={'like_sum': 'like', 'reply_sum': 'reply', 'retweet_sum': 'retweet', 'clean_nunique': 'unique keyword'},
                              height=400)
                fig.update_yaxes(visible=False, fixedrange=True)
                fig.update_layout(showlegend=False)

                st.plotly_chart(fig, use_container_width=True)

            st.dataframe(data2,
                         hide_index=True,
                         column_config={
                            'clean': 'Keyword',
                            'like_count': "Tweets",
                            'like_sum': 'Likes',
                            'reply_sum': 'Replies',
                            'retweet_sum': 'Retweets',
                            'interaction_sum': 'Engagement',
                            'username_nunique': 'User',
                            'clean_nunique': 'Total Keyword',
                            'clean_unique': 'Unique Keyword'
                        },
                        use_container_width=True)

            st.markdown("## Keyword Details")
            st.dataframe(df_tweet[['clean', 'like_count', 'username_nunique', 'retweet_sum', 'like_sum', 'reply_sum', 'interaction_sum']],
                         use_container_width=True,
                         hide_index=True,
                         column_config={
                            'clean': 'Keyword',
                            'like_count': "Tweets",
                            'like_sum': 'Likes',
                            'reply_sum': 'Replies',
                            'retweet_sum': 'Retweets',
                            'interaction_sum': 'Engagement',
                            'username_nunique': 'User',
                        })

except Error as e:
    st.error("Tidak dapat terhubung ke database, periksa koneksi database terlebih dahulu.")
