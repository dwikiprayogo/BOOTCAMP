import mysql.connector as sql
from mysql.connector import Error
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st
import altair as alt
from urllib.error import URLError
from babel.numbers import format_currency
from numerize import numerize
from helper import generate_wordcloud, add_logo
import plotly.express as px
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline

st.set_page_config(page_title="Analisa Kandidat Bootcamp Influencer 2024",
                   page_icon="📈",
                   layout="wide")

style = """
<style>
    #MainMenu {visibility: hidden;}
    header {visibility: hidden;}
    footer {visibility: hidden;}
</style>
"""

st.markdown(style, unsafe_allow_html=True)

try:
    db_connection = sql.connect(
        host='10.240.20.20', 
        database='bootcamp', 
        user='root', 
        password='ZNqOhS/VS/Pd8w', 
        port='8906'
    )
    df = pd.read_sql('SELECT * FROM bootcamp_dashboard_collection', con=db_connection)
    df_training = pd.read_sql('SELECT * FROM `bootcamp_data_training`', con=db_connection)

    if 'username' not in df.columns:
        st.error("Kolom 'username' tidak ditemukan dalam data. Pastikan kolom ini ada dalam tabel.")
    else:
        df['reply_count'] = pd.to_numeric(df['reply_count'], errors='coerce')
        df['quote_count'] = pd.to_numeric(df['quote_count'], errors='coerce')
        df['favorite_count'] = pd.to_numeric(df['favorite_count'], errors='coerce')

        df['interaction'] = df['reply_count'] + df['quote_count'] + df['favorite_count']
        df['created_at'] = df['created_at'].apply(lambda x: x[:10])

        X_train = df_training['full_text']
        y_train = df_training['sentiment']

        model = make_pipeline(CountVectorizer(), MultinomialNB())
        model.fit(X_train, y_train)

        df['predicted_sentiment'] = model.predict(df['full_text'])

        df_sentiment = pd.DataFrame(df['predicted_sentiment'].value_counts()).reset_index()
        df_sentiment.columns = ['sentiment', 'count']

        df_tweet = df.groupby(["created_at"]).agg({
            'favorite_count': ['count', 'sum'],
            'reply_count': ['sum'],
            'quote_count': ['sum']
        }).reset_index()
        df_tweet.columns = [col[0] if col[1] == '' else col[0] + '_' + col[1] for col in df_tweet.columns]

        add_logo("https://upload.wikimedia.org/wikipedia/commons/archive/c/ce/20210909091155%21Twitter_Logo.png",150)

        "# Analisis Sentimen Media Sosial Peserta Bootcamp BCA 2024"
        "Bootcamp Influencer 2024 PT. Benih Citra Asia"

        try:
            list_users = df.set_index("username")    
            candidate = st.multiselect(
                "Pilih Kandidat", list(list_users.index)
            )
            
            if candidate:
                data_list = list_users.loc[candidate].reset_index()
                data_list.index = data_list.index + 1

                st.write("### Daftar Kandidat : ")
                
                for i, user in enumerate(candidate, start=1):
                    st.write(f"{i}. **{user}**")

                st.write("### Tabel Komentar dari Kandidat yang Dipilih")
                st.write(data_list[['username', 'full_text']])
        except URLError as e:
            st.error(
                """
                *This demo requires internet access.* 
                Connection error: %s
            """ % e.reason
            )
        "\n"
        a11, a12 = st.columns(2)
        a21, a22 = st.columns(2)

        with a11:
            st.metric(label="Jumlah Tweet",
                value=f"{numerize.numerize(df.shape[0])}"
                )
            
            fig = px.line(df_tweet, x='created_at', y='favorite_count_count',
                     hover_data=['favorite_count_sum', 'reply_count_sum', 'quote_count_sum'], 
                     labels={'favorite_count_sum':'Favorite',
                             'reply_count_sum':'Reply',
                             'quote_count_sum':'Quote',
                             'favorite_count_count':'Tweet'},
                    height=400
                    )
            fig.update_yaxes(visible=False, fixedrange=True)

            st.plotly_chart(
                fig,
                use_container_width=True
            )

        with a12:
            st.metric(label="Jumlah Interaksi",
            value=f"{numerize.numerize(df['interaction'].sum().item())}"
            )
            fig = px.line(df_tweet, x='created_at', y='favorite_count_sum',
                     hover_data=['favorite_count_sum', 'reply_count_sum', 'quote_count_sum'], 
                     labels={'favorite_count_sum':'Favorite',
                             'reply_count_sum':'Reply',
                             'quote_count_sum':'Quote'},
                    height=400
                    )
            fig.update_yaxes(visible=False, fixedrange=True)

            st.plotly_chart(
                fig,
                use_container_width=True
            )

        with a21:
            "Wordcloud"
            wc = generate_wordcloud(df['full_text'])
            plt.figure(figsize=(10,8))
            plt.imshow(wc, interpolation='bilinear')
            plt.axis("off")
            st.pyplot(plt)

        with a22:
            "Sentimen Pengguna"
            fig = px.pie(df_sentiment, names='sentiment', values='count')
            fig.update_traces(textposition='inside', textinfo='percent+label', textfont_size=18,)
            fig.update_layout(showlegend=False,
                              margin=dict(l=20, r=20, t=20, b=20),
            )
            st.plotly_chart(
                fig,
                use_container_width=True
            )

except Error as e:
    st.error("Tidak dapat terhubung ke database, Periksa koneksi database terlebih dahulu.")
